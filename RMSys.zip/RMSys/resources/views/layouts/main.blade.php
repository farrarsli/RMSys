<!DOCTYPE html>
<html lang="en">

<head>
    @include('layouts.partials.head')

</head>

<body>
    @yield('sideNav')
    @include('layouts.partials.footer-scripts')
</body>

</html>