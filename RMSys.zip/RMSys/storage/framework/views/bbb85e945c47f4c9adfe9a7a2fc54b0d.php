
<?php $__env->startSection('sideNav'); ?>

<div class="container-fluid">
    <div class="row">
        <!-- Main Sidebar -->
        <aside class="main-sidebar col-12 col-md-3 col-lg-2 px-0" >
            <div class="main-navbar">
                <nav class="navbar align-items-stretch navbar-light bg-white flex-md-nowrap border-bottom p-0" >
                    <a class="navbar-brand w-100 mr-0" href="<?php echo e(route('dashboard')); ?>" style="line-height: 25px; background-color: #ffd700;">
                        <div class="d-table m-auto">
                            <img id="main-logo" class="d-inline-block align-center mr-3" style="max-width: 40px;" src="<?php echo e(asset('frontend')); ?>/images/logo.png" alt="RMSys logo">
                            <span class="d-none d-md-inline ml-1" style="color: white"> <?php echo e(config('app.name', 'RMsys')); ?></span>
                        </div>
                    </a>
                    <a class="toggle-sidebar d-sm-inline d-md-none d-lg-none">
                        <i class="material-icons">&#xE5C4;</i>
                    </a>
                </nav>
            </div>

            <div class="nav-wrapper" style="background-color: #bd1924;">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('dashboard*') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
                            <i class="material-icons" style="color: white;">info</i>
                            <b><span style="color: white;">Dashboard</span></b>
                        </a>
                    </li>

                    <!-- CLERK SIDENAV-->
                    <?php if( auth()->user()->category== "Clerk"): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('listuser*') ? 'active' : ''); ?>" href="<?php echo e(route('listuser')); ?>">
                            <i class="material-icons" style="color: white;">work</i>
                            <span style="color: white;">Manage Registration</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('listproduct*') ? 'active' : ''); ?>" href="<?php echo e(route('listproduct')); ?>">
                            <i class="material-icons" style="color: white;">work</i>
                            <span style="color: white;">Manage Product</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('branchlimit*') ? 'active' : ''); ?>" href="<?php echo e(route('branchlimit')); ?>">
                            <i class="material-icons" style="color: white;">work</i>
                            <span style="color: white;">Branch Limit</span>
                        </a>
                    </li>
                    <?php endif; ?>

                    <!-- BRANCH MANAGER SIDENAV-->
                    <?php if( auth()->user()->category== "Manager"): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('listsales*') ? 'active' : ''); ?>" href="<?php echo e(route('listsales')); ?>">
                            <i class="material-icons" style="color: white;">money</i>
                            <b><span style="color: white;">Sales</span></b>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('listproduct*') ? 'active' : ''); ?>" href="<?php echo e(route('listproduct')); ?>">
                            <i class="material-icons" style="color: white;">inventory</i>
                           <b><span style="color: white;">Request Product</span></b>
                        </a>
                    </li>
                    <?php endif; ?>

                    <!-- OWNER SIDENAV-->
                    <?php if( auth()->user()->category== "Owner"): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('salesapproval*') ? 'active' : ''); ?>" href="<?php echo e(route('salesapproval')); ?>">
                            <i class="material-icons" style="color: white;">money</i>
                            <b><span style="color: white;">Sales Approval </span></b>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('listproduct*') ? 'active' : ''); ?>" href="<?php echo e(route('listproduct')); ?>">
                            <i class="material-icons" style="color: white;">inventory</i>
                           <b><span style="color: white;">Registered Users</span></b>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('listproduct*') ? 'active' : ''); ?>" href="<?php echo e(route('listproduct')); ?>">
                            <i class="material-icons" style="color: white;">inventory</i>
                           <b><span style="color: white;">Registered Products</span></b>
                        </a>
                    </li>
                    <?php endif; ?>

                     <!--GROUP SEP END -->

                </ul>


            </div>

        </aside>
        <!-- End Main Sidebar -->
        <main class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3">
            <div class="main-navbar sticky-top bg-white">
                <!-- Main Navbar -->
                <nav class="navbar align-items-stretch navbar-light flex-md-nowrap p-0">

                    <div class="row mt-auto mb-auto ml-3 " style="width: auto;">

                        <div class="d-md-flex mt-auto mb-auto mr-md-4 d-none" style="width: auto">

                        </div>

                    </div>
                    <ul class="navbar-nav border-left flex-row ml-auto ">
                        <li class="nav-item border-right dropdown">
                            <a class="nav-link dropdown-toggle text-nowrap px-3" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                                <img class="user-avatar rounded-circle mr-2" src="<?php echo e(asset('frontend')); ?>/images/avatar.jpg" alt="Avatar" width="30px" height="30px" style="vertical-align:baseline">
                                <span class="d-none d-md-inline-block"><strong><?php echo e(Auth::user()->name); ?></strong><br> <?php echo e(Auth::user()->category); ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-small">
                                <a class="dropdown-item">
                                    <i class="material-icons">&#xE7FD;</i> Profile</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item text-danger" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <i class="material-icons text-danger">&#xE879;</i> Logout </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    </ul>
                    <nav class="nav">
                        <a href="#" class="nav-link nav-link-icon toggle-sidebar d-md-inline d-lg-none text-center border-left" data-toggle="collapse" data-target=".header-navbar" aria-expanded="false" aria-controls="header-navbar">
                            <i class="material-icons">&#xE5D2;</i>
                        </a>
                    </nav>
                </nav>
            </div>
            <!-- / .main-navbar -->

            <?php if(session()->get('success')): ?>
            <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <i class="fa fa-check mx-2"></i>

                <?php echo e(session()->get('success')); ?>

            </div>
            <?php endif; ?>

            <?php if(session()->get('failed')): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-0" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <i class="fa fa-times mx-2"></i>

                <?php echo e(session()->get('failed')); ?>

            </div>
            <?php endif; ?>

            <div class="main-content-container container-fluid px-4">
                <br>
                <?php echo $__env->yieldContent('content'); ?>
            </div>

            <footer class="main-footer d-flex p-2 px-3 bg-white border-top">
                <span class="copyright ml-auto my-auto mr-2">Copyright © <?php echo e(now()->year); ?>

                    <a href="#" rel="nofollow">RMSRay</a>
                </span>
            </footer>

    </div>
</div>

<!-- End Page Header -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RMSys\RMSys\resources\views/layouts/sideNav.blade.php ENDPATH**/ ?>