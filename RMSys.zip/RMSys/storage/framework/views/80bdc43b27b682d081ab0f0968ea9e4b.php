

<?php $__env->startSection('content'); ?>

<center><h2>List of Registered Product</h2></center>
<section class="p-5">
    <div class="container" width="100px">
        <div class="overflow-auto" style="overflow:auto;">
            <div class="table-responsive">
                <div class="col-lg-3 col-md-2 col-sm-2" style="float: left;">
                    <a class="btn btn-success" style="float: left; width:70%;" role="button" href="<?php echo e(route('addproduct')); ?>">
                        <i class="fas fa-plus"></i>&nbsp; Add New Product</a><br>
                </div><br><br><br>
                <div class="card">
                <div class="card-body">
                <table class="table table-bordered" id="dataTable" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Product Detail</th>
                            <th>Stock Available</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $productRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr id="row<?php echo e($data->id); ?>">

                            <td><?php echo e($data->productname); ?></td>
                            <td><?php echo e($data->productdetail); ?></td>
                            <td><?php echo e($data->stock); ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?php echo e(route('updateProduct',$data->id)); ?>" class="btn btn-primary">Update Stock</a>
                                    <button class="btn btn-danger" type="button" onclick="deleteItem(this)" data-id="<?php echo e($data->id); ?>" data-name="<?php echo e($data->productname); ?>">Delete Product</button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table></div>
            </div>
                
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<script>
    function deleteItem(e) {
        let id = e.getAttribute('data-id');
        let name = e.getAttribute('data-name');

        const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
                confirmButton: 'btn btn-success ml-1',
                cancelButton: 'btn btn-danger mr-1'
            },
            buttonsStyling: false
        });

        swalWithBootstrapButtons.fire({
            title: 'Are you sure?',
            html: "Name: " + name + "<br> You won't be able to revert this!",
            text: "",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
            reverseButtons: true
        }).then((result) => {
            if (result.value) {
                if (result.isConfirmed) {

                    $.ajax({
                        type: 'DELETE',
                        url: '<?php echo e(url("/deleteProduct")); ?>/' + id,
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>",
                        },
                        success: function(data) {
                            if (data.success) {
                                swalWithBootstrapButtons.fire(
                                    'Deleted!',
                                    'User account has been deleted.',
                                    "success"
                                );

                                $("#row" + id).remove(); // you can add name div to remove
                            }


                        }
                    });

                }

            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                // swalWithBootstrapButtons.fire(
                //     'Cancelled',
                //     'Your imaginary file is safe :)',
                //     'error'
                // );
            }
        });

    }
    
</script>
<?php echo $__env->make('layouts.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RMSys\RMSys\resources\views/product/listproduct.blade.php ENDPATH**/ ?>