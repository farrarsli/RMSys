<?php
$images = ['img1.jpg', 'img2.jpg', 'img3.jpg'];
?>

<div class="swiper-container">
  <div class="swiper-wrapper">
    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="swiper-slide">
        <img src="<?php echo e(asset('frontend/images/'.$image)); ?>" alt="Slide" style="width: 400px; height: 200px;">
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="swiper-pagination"></div>
</div><?php /**PATH C:\xampp\htdocs\RMSys\RMSys\resources\views/slideshow.blade.php ENDPATH**/ ?>