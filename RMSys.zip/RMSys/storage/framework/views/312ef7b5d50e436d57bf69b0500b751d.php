
<?php $__env->startSection('content'); ?>

<center>
    <h2>Sales Approval</h2>
</center><br>

<div class="card">
<div class="card-body">
    <table class="table table-bordered" id="dataTable" cellspacing="0">
        <thead>
            <tr>
                <th>Branch</th>
                <th>Sales Date</th>
                <th>Total Sales</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $salesRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr id="row<?php echo e($data->id); ?>">

                <td><?php echo e($data->branchname); ?></td>
                <td><?php echo e($data->salesdate); ?></td>
                <td><?php echo e($data->totalsales); ?></td>
                <td><?php echo e($data->sales_status); ?></td>
                <td>
                    <a class="btn btn-primary" data-toggle="modal" data-target="#viewPassModal" style="color: white; width:100%;">View</a>
                </td>

            </tr>
            <div class="modal fade" id="viewPassModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="myModalLabel">Sales image</h5>
                            
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="justify-content-center text-center">
                                <img src="/assets/pass/<?php echo e($data->sales_img); ?>" width="400px">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <?php if( $data->sales_status== "Pending"): ?>
                                    <!--approve registration-->
                                    <a class="btn btn-success" href="<?php echo e(route('approval',$data->id)); ?>">Approve</a>
                                    <!--reject registration-->
                                    <a class="btn btn-danger" href="<?php echo e(route('reject',$data->id)); ?>">Reject</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>



<?php $__env->stopSection(); ?>








<?php echo $__env->make('layouts.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RMSys\RMSys\resources\views/sales/salesapproval.blade.php ENDPATH**/ ?>